package com.example.clothshop1;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ClController {
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	   public String index() {
	      return "index";
	   }
	
	@GetMapping("/Admin")
	public String getNavbar() {
		return "Admin";
	}
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@GetMapping("/otp")
	public String otpp() {
		return "otp";
	}
	@GetMapping("/registration")
	public String register() {
		return "registration";
	}
	
}
