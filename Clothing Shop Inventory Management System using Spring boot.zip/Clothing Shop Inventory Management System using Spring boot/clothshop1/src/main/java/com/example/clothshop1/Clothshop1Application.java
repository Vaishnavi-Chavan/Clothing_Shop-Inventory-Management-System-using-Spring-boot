package com.example.clothshop1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clothshop1Application {

	public static void main(String[] args) {
		SpringApplication.run(Clothshop1Application.class, args);
	}

}
