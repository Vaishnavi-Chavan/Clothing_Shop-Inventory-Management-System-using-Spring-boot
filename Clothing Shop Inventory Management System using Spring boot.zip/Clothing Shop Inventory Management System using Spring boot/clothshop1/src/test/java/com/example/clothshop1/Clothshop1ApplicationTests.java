package com.example.clothshop1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clothshop1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
